# Harjoitustyön suunnitelma

(Täydennä oman pelisi tiedot tähän tiedostoon muokkaamalla 
tiedostoa tekstieditorissa. Käytä [Markdown-syntaksia](https://about.gitlab.com/handbook/markdown-guide/).
Poista sitten *kaikki* suluilla merkityt kohdat.)

## Tietoja 

Tekijä: Otto Karppinen

Työ git-varaston osoite: <https://gitlab.jyu.fi/karpot/ohj1ht>

Pelin nimi: Robinin hyppelypeli

Pelialusta: Windows

Pelaajien lukumäärä: 1

## Pelin tarina

Moni ei tiedä että Batmanin Robin rakastaa tomaattimurskaa. Pelissä on tarkoitus kerätä kaikki tomaatit, jolloin peli päättyy. Tasohyppelykentällä liikkuu vihollisia joihin ei saa osua. Pelissä on myös aikaraja jolloin peli päättyy. Peli loppuu joko keräämällä kaikki objektit tai osumalla viholliseen tai ajastimeen.

## Pelin idea ja tavoitteet

Pelin tavoitteena on saattaa Robinilla kerättyä kaikki tomaatit jotta hänellä olisi tarpeeksi voimia purkaa pahan Banen pommi.

## Hahmotelma pelistä

![Esimerkkikuva](robin.png "Robin")
![Volo](tomaatti.png "tomaattimurska")
![bunkkeri](bane.png "Bane")
![ukraina](pommi.png "Räjähdys")

## Toteutuksen suunnitelma

Helmikuu

- Kartta ja pari objektia asennettu

Maaliskuu

- Tasot asennettu
- pari vihua tehtyä, eivät vielä liiku
- Pelissä on ajastin

Jos aikaa jää

- Kaikki vihut liikkuu
- Pelissä on ajastin joka kerää ennätyksiä ja ottaa ne talteen listaan
